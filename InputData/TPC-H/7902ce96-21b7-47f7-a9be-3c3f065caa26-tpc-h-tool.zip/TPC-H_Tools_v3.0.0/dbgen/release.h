/*
 * release.h
 */
#define VERSION 3
#define RELEASE 0
#define PATCH 0
#define BUILD 0
